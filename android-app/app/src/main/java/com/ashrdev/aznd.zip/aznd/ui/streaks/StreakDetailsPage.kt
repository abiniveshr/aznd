package com.ashrdev.aznd.ui.streaks

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ashrdev.aznd.data.streaks.StreakEntity
import com.ashrdev.aznd.domain.streaks.BrokenStats
import com.ashrdev.aznd.domain.streaks.ProgressUnit
import com.ashrdev.aznd.domain.streaks.StreakStats
import com.ashrdev.aznd.domain.streaks.displayDate
import com.ashrdev.aznd.ui.components.Card
import com.ashrdev.aznd.ui.components.StatTile
import com.ashrdev.aznd.ui.theme.Space

private fun days(n: Int) = "$n day${if (n == 1) "" else "s"}"

/**
 * Centre page of the streak screen: banner photo, icon + name + day count, key numbers and the next
 * milestone, which takes whatever room is left so the page is full. (Edit and Delete are in the top
 * bar; day actions are on Calendar.)
 */
@Composable
fun StreakDetailsPage(
    streak: StreakEntity,
    stats: StreakStats,
    broken: BrokenStats,
    hasMilestones: Boolean,
    bottomPadding: Dp,
    onPickBanner: () -> Unit,
    onPickLogo: () -> Unit,
    unit: ProgressUnit = ProgressUnit.DAYS,
    missed: Int? = null
) {
    val scroll = rememberScrollState()
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val roomy = maxHeight >= ROOMY_HEIGHT
        Column(
            modifier = Modifier
                .fillMaxSize()
                .then(if (roomy) Modifier else Modifier.verticalScroll(scroll))
                .padding(start = Space.lg, end = Space.lg, top = Space.lg, bottom = bottomPadding),
            verticalArrangement = Arrangement.spacedBy(Space.md)
        ) {
            StreakBannerCard(bannerUri = streak.bannerUri, onPick = onPickBanner)
            StreakIdentityCard(
                streak = streak,
                count = stats.current,
                onLogoClick = onPickLogo,
                countText = if (unit == ProgressUnit.DAYS) null else unit.describeDays(stats.current)
            )

            if (missed != null) {
                StatTile(
                    label = "Times missed",
                    value = if (missed == 1) "1 time" else "$missed times",
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(Space.md)
                ) {
                    StatTile(
                        label = "Times broken",
                        value = if (broken.events == 1) "1 time" else "${broken.events} times",
                        modifier = Modifier.weight(1f)
                    )
                    StatTile(
                        label = "Longest streak",
                        value = days(stats.longest),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            MilestoneCard(
                stats = stats,
                hasMilestones = hasMilestones,
                unit = unit,
                modifier = if (roomy) Modifier.weight(1f) else Modifier.heightIn(min = MILESTONE_MIN_HEIGHT)
            )
        }
    }
}

@Composable
private fun MilestoneCard(stats: StreakStats, hasMilestones: Boolean, unit: ProgressUnit, modifier: Modifier = Modifier) {
    val next = stats.nextMilestone
    val date = stats.nextMilestoneDate
    Card(modifier = modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(Space.lg),
            verticalArrangement = Arrangement.spacedBy(Space.sm, Alignment.CenterVertically)
        ) {
            Text(
                "Upcoming milestone",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (next != null && date != null) {
                Text(unit.describeDays(next), style = MaterialTheme.typography.displaySmall)
                Text(displayDate(date), style = MaterialTheme.typography.bodyLarge)
                MilestoneProgressBar(
                    previous = stats.previousMilestone,
                    next = next,
                    current = stats.current,
                    unit = unit,
                    modifier = Modifier.padding(top = Space.xl)
                )
            } else {
                Text(
                    if (hasMilestones) "All milestones reached" else "No milestones set",
                    style = MaterialTheme.typography.titleMedium
                )
            }
        }
    }
}

private const val BAR_PARTS = 10
private val ROOMY_HEIGHT = 560.dp
private val MILESTONE_MIN_HEIGHT = 200.dp

/**
 * The stretch from the previous milestone to the next, cut into [BAR_PARTS] equal parts. The day
 * count at each boundary sits above the bar (first = previous milestone, last = next milestone);
 * a solid circle marks today's position with "current/next" underneath.
 */
@Composable
private fun MilestoneProgressBar(
    previous: Int,
    next: Int,
    current: Int,
    unit: ProgressUnit,
    modifier: Modifier = Modifier
) {
    val measurer = rememberTextMeasurer()
    val primary = MaterialTheme.colorScheme.primary
    val track = MaterialTheme.colorScheme.surfaceVariant
    val divider = MaterialTheme.colorScheme.surface
    val labelStyle = TextStyle(fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    val markerStyle = TextStyle(fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
    val span = (next - previous).coerceAtLeast(1)
    val fraction = ((current - previous).toFloat() / span).coerceIn(0f, 1f)
    val previousUnits = unit.completed(previous)
    val nextUnits = unit.completed(next)
    val currentUnits = unit.completed(current)
    val unitSpan = nextUnits - previousUnits

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp)
    ) {
        val inset = 0.dp.toPx()
        val barLeft = inset
        val barRight = size.width - inset - 1
        val barW = barRight - barLeft
        val barTop = 20.dp.toPx()
        val barH = 8.dp.toPx()
        val barBottom = barTop + barH
        val corner = 4.dp.toPx()

        // Day count at every other boundary, above the bar.
        for (k in 0..BAR_PARTS step 2) {
                val x = barLeft + barW * k / BAR_PARTS
                val value = when {
                    unit == ProgressUnit.DAYS -> Math.round(previous + span * k / BAR_PARTS.toDouble()).toInt()
                    unitSpan >= BAR_PARTS -> Math.round(previousUnits + unitSpan * k / BAR_PARTS.toDouble()).toInt()
                    k == 0 -> previousUnits
                    k == BAR_PARTS -> nextUnits
                    else -> continue
                }
                val layout = measurer.measure(value.toString(), labelStyle)
                val labelX = (x - layout.size.width / 2f).coerceIn(0f, size.width - layout.size.width)
                drawText(layout, topLeft = Offset(labelX, barTop - 4.dp.toPx() - layout.size.height))
        }

        // The bar: track, progress, and the dividers between the parts.
        val shape = Path().apply {
            addRoundRect(RoundRect(barLeft, barTop, barRight, barBottom, corner, corner))
        }
        clipPath(shape) {
            drawRect(track, Offset(barLeft, barTop), Size(barW, barH))
            drawRect(primary, Offset(barLeft, barTop), Size(barW * fraction, barH))
            for (k in 1 until BAR_PARTS) {
                val x = barLeft + barW * k / BAR_PARTS
                drawLine(divider, Offset(x, barTop), Offset(x, barBottom), strokeWidth = 1.5.dp.toPx())
            }
        }
        val progressX = barLeft + barW * fraction
            for (k in 1 until BAR_PARTS + 1) {
            val x = barLeft + barW * k / BAR_PARTS
            // gap-coloured inside the filled part, bar-coloured in the empty part
            val markColor = if (x <= progressX) divider else primary
            drawLine(markColor, Offset(x, barTop), Offset(x, barBottom), strokeWidth = 1.5.dp.toPx())
        }
        // Today: a solid circle on the bar, current/next below it.
        val markerX = barLeft + barW * fraction
        val markerY = barTop + barH / 2f
        drawCircle(divider, radius = 9.dp.toPx(), center = Offset(markerX, markerY))
        drawCircle(primary, radius = 6.5.dp.toPx(), center = Offset(markerX, markerY))
        val markerLayout = measurer.measure(if (unit == ProgressUnit.DAYS) "$current/$next" else "$currentUnits/$nextUnits", markerStyle)
        val markerTextX = (markerX - markerLayout.size.width / 2f)
            .coerceIn(0f, size.width - markerLayout.size.width)
        drawText(markerLayout, topLeft = Offset(markerTextX, markerY + 12.dp.toPx()))
    }
}
