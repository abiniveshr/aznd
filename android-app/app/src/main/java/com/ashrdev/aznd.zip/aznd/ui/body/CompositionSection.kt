package com.ashrdev.aznd.ui.body

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ashrdev.aznd.data.body.BodyMeasurement
import com.ashrdev.aznd.data.body.BodyWeightEntry
import com.ashrdev.aznd.domain.body.BodyStats
import com.ashrdev.aznd.domain.GraphMode
import com.ashrdev.aznd.domain.GraphPoint
import com.ashrdev.aznd.domain.GraphRange
import com.ashrdev.aznd.domain.GraphStyle
import com.ashrdev.aznd.domain.GraphWindow
import com.ashrdev.aznd.domain.body.MeasurementSite
import com.ashrdev.aznd.ui.components.Card
import com.ashrdev.aznd.ui.components.OutlinedButton
import com.ashrdev.aznd.ui.components.StatTile
import com.ashrdev.aznd.ui.theme.Space

/**
 * The Composition page of the Body screen: log bodyweight and body fat %, see the latest numbers
 * with lean mass (calculated from the latest weight and body fat), and buttons that open the
 * bodyweight / body fat history (calendar, graph, logs).
 * The latest bodyweight is what new workouts use; the Macros goal reads weight and body fat from here.
 */
fun LazyListScope.compositionSection(
    weights: List<BodyWeightEntry>?,
    measurements: List<BodyMeasurement>?,
    range: GraphRange,
    onLogWeight: (kg: Double, atMs: Long) -> Unit,
    onLogBodyFat: (percent: Double, atMs: Long) -> Unit,
    onOpenHistory: (CompositionMetric) -> Unit
) {
    item(key = "weight-log") {
        LogEntryCard(
            label = "Bodyweight", unit = "kg",
            min = BodyStats.MIN_WEIGHT_KG, max = BodyStats.MAX_WEIGHT_KG
        ) { kg, at -> onLogWeight(kg, at) }
    }
    item(key = "fat-log") {
        LogEntryCard(
            label = "Body fat", unit = "%",
            min = BodyStats.MIN_BODY_FAT, max = BodyStats.MAX_BODY_FAT
        ) { pct, at -> onLogBodyFat(pct, at) }
    }

    val weightList = weights ?: return
    val fatList = measurements.orEmpty().filter { it.site == MeasurementSite.BODY_FAT.name } // newest first

    if (weightList.isEmpty()) {
        item(key = "weight-empty") {
            Text(
                "Log your first weight above. New workouts use your latest weight for bodyweight " +
                    "exercises (75 kg is the default place holder).",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    } else {
        val ascending = weightList.sortedBy { it.measuredAt }
        item(key = "cards") {
            val shown = GraphWindow.select(ascending, range, System.currentTimeMillis()) { it.measuredAt }
            val change = if (shown.size >= 2) shown.last().weightKg - shown.first().weightKg else 0.0
            val weight = weightList.first().weightKg
            val bodyFat = fatList.firstOrNull()?.valueCm
            Column(verticalArrangement = Arrangement.spacedBy(Space.md)) {
                Row(horizontalArrangement = Arrangement.spacedBy(Space.md), modifier = Modifier.fillMaxWidth()) {
                    StatTile("Weight", "${GraphWindow.formatValue(weight)} kg", Modifier.weight(1f))
                    StatTile("Change in range", "${BodyStats.signed(change)} kg", Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(Space.md), modifier = Modifier.fillMaxWidth()) {
                    StatTile("Body fat", bodyFat?.let { "${GraphWindow.formatValue(it)} %" } ?: "—", Modifier.weight(1f))
                    StatTile(
                        "Lean mass",
                        bodyFat?.let { "${GraphWindow.formatValue(BodyStats.leanMassKg(weight, it))} kg" } ?: "—",
                        Modifier.weight(1f)
                    )
                }
                Text(
                    if (bodyFat == null) "Log a body fat % above to see your lean mass."
                    else "Lean mass = weight × (1 − body fat %), from your latest entries.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }

    item(key = "history-buttons") {
        Row(horizontalArrangement = Arrangement.spacedBy(Space.md), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(
                onClick = { onOpenHistory(CompositionMetric.WEIGHT) },
                modifier = Modifier.weight(1f)
            ) { Text("Bodyweight history", maxLines = 1) }
            OutlinedButton(
                onClick = { onOpenHistory(CompositionMetric.BODY_FAT) },
                modifier = Modifier.weight(1f)
            ) { Text("Body fat history", maxLines = 1) }
        }
    }
}

/**
 * The trend graph views of the weight history screen: weight, 7-day average and, when body fat is
 * logged, body fat and lean mass. Both lists in any order.
 */
fun weightTrendModes(weights: List<BodyWeightEntry>, measurements: List<BodyMeasurement>): List<GraphMode> {
    val raw = weights.sortedBy { it.measuredAt }.map { GraphPoint(it.measuredAt, it.weightKg) }
    val fat = measurements.filter { it.site == MeasurementSite.BODY_FAT.name }
        .sortedBy { it.measuredAt }
        .map { GraphPoint(it.measuredAt, it.valueCm) }
    return buildList {
        add(GraphMode("weight", "Weight", "kg", GraphStyle.LINE, raw, startAtZero = false))
        add(GraphMode("avg", "7-day average", "kg", GraphStyle.LINE, BodyStats.rollingAverage(raw), startAtZero = false))
        if (fat.isNotEmpty()) {
            add(GraphMode("fat", "Body fat", "%", GraphStyle.LINE, fat, startAtZero = false))
            add(GraphMode("lean", "Lean mass", "kg", GraphStyle.LINE, BodyStats.leanMassSeries(raw, fat), startAtZero = false))
        }
    }
}

/** One history line with a delete button. */
@Composable
internal fun HistoryRow(title: String, subtitle: String, onDelete: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(start = Space.lg, top = Space.xs, bottom = Space.xs, end = Space.xs)
        ) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete entry", tint = MaterialTheme.colorScheme.error)
            }
        }
    }
}
