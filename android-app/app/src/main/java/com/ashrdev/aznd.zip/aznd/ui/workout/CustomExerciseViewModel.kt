package com.ashrdev.aznd.ui.workout

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.ashrdev.aznd.data.workout.CustomExerciseForm
import com.ashrdev.aznd.data.workout.FormError
import com.ashrdev.aznd.data.workout.TrainingRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Form state + save for a custom exercise. Errors are shown only after the first Save attempt.
 * Custom exercises are not editable once created.
 */
class CustomExerciseViewModel(private val repository: TrainingRepository) : ViewModel() {

    private val _form = MutableStateFlow(CustomExerciseForm())
    val form: StateFlow<CustomExerciseForm> = _form.asStateFlow()

    private val _errors = MutableStateFlow<Set<FormError>>(emptySet())
    /** Empty until Save was pressed once; then refreshed on every edit. */
    val errors: StateFlow<Set<FormError>> = _errors.asStateFlow()

    private val _saved = MutableStateFlow(false)
    val saved: StateFlow<Boolean> = _saved.asStateFlow()

    private var attempted = false
    private var nameTaken = false

    fun update(op: (CustomExerciseForm) -> CustomExerciseForm) {
        _form.update(op)
        if (attempted) _errors.value = _form.value.errors(nameTaken && _form.value.cleanName.isNotEmpty())
    }

    fun save() {
        val f = _form.value
        viewModelScope.launch {
            attempted = true
            nameTaken = f.cleanName.isNotEmpty() && repository.exerciseNameTaken(f.cleanName)
            val errs = f.errors(nameTaken)
            _errors.value = errs
            if (errs.isEmpty()) {
                f.toExercise()?.let { repository.addCustomExercise(it) }
                _saved.value = true
            }
        }
    }

    companion object {
        fun factory(repository: TrainingRepository): ViewModelProvider.Factory =
            viewModelFactory { initializer { CustomExerciseViewModel(repository) } }
    }
}
