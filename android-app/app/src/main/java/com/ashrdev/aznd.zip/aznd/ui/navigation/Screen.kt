package com.ashrdev.aznd.ui.navigation

/*
 * Route map (what opens what). Back always returns to the screen you came from;
 * the Home button returns to the Home page.
 *
 * Home (pager: History | Home | Dashboard)
 *  |- Workouts -------- WorkoutLog
 *  |                     |- Add workout ------ WorkoutEditor
 *  |                     |- a workout -------- WorkoutView
 *  |                     |                       |- Start ---- WorkoutLogger -- Finish --> (back)
 *  |                     |                       |- Stats ---- WorkoutStats -- ExerciseView -- SessionDetail
 *  |                     |                       |- Edit ----- WorkoutEditor
 *  |                     |                       '- exercise -- ExerciseView
 *  |                     '- session in progress - WorkoutLogger
 *  |- Streaks --------- Streaks
 *  |                     |- Add streak ------- StreakEditor
 *  |                     '- a streak ---------- StreakDetail
 *  |                                             |- Saved (book) -- SavedDaysForStreak -- SavedDayDetail
 *  |                                             '- Save today ---- SavedDayDetail
 *  |- History page
 *  |    |- Workout History -- History (pick a workout) -- WorkoutHistory (calendar) -- SessionDetail
 *  |    |                                                   '- Stats -- WorkoutStats
 *  |    '- Saved Streaks ---- SavedDays (pick a streak) -- SavedDaysForStreak (calendar) -- SavedDayDetail
 *  '- Dashboard page: streak card -> StreakDetail, top lift -> ExerciseView
 *
 * Settings -> Appearance opens from the pull-up bar on every screen.
 */
sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Settings : Screen("settings")
    object Appearance : Screen("settings_appearance")

    object WorkoutLog : Screen("workout_log")
    object History : Screen("history")
    object WorkoutHistory : Screen("workout_history/{workoutId}") {
        fun createRoute(workoutId: Long) = "workout_history/$workoutId"
    }
    object WorkoutStats : Screen("workout_stats/{workoutId}") {
        fun createRoute(workoutId: Long) = "workout_stats/$workoutId"
    }
    object WorkoutLogger : Screen("workout_logger/{workoutId}") {
        fun createRoute(workoutId: Long) = "workout_logger/$workoutId"
    }
    object CustomExercise : Screen("custom_exercise")
    object WorkoutView : Screen("workout_view/{workoutId}") {
        fun createRoute(workoutId: Long) = "workout_view/$workoutId"
    }
    object ExerciseView : Screen("exercise_view/{workoutId}/{exerciseId}") {
        fun createRoute(workoutId: Long, exerciseId: Long) = "exercise_view/$workoutId/$exerciseId"
    }
    object WorkoutEditor : Screen("workout_editor?workoutId={workoutId}") {
        fun createRoute(workoutId: Long?) = "workout_editor?workoutId=${workoutId ?: -1}"
    }
    object SessionDetail : Screen("session/{sessionId}") {
        fun createRoute(sessionId: Long) = "session/$sessionId"
    }

    object Streaks : Screen("streaks")
    object StreakEditor : Screen("streak_editor")
    object StreakDetail : Screen("streak_detail/{streakId}") {
        fun createRoute(streakId: Long) = "streak_detail/$streakId"
    }
    object SavedDays : Screen("saved_days")
    object SavedDaysForStreak : Screen("saved_days/{streakId}") {
        fun createRoute(streakId: Long) = "saved_days/$streakId"
    }
    object SavedDayDetail : Screen("saved_day/{streakId}/{date}") {
        fun createRoute(streakId: Long, date: String) = "saved_day/$streakId/$date"
    }
}
