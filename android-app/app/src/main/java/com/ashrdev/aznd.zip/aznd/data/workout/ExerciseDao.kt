package com.ashrdev.aznd.data.workout

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/** Data access object for catalog and custom exercise entities. */
@Dao
interface ExerciseDao {

    /** INSERT OR IGNORE: a row whose seedKey already exists is skipped and reports -1. */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIgnore(items: List<Exercise>): List<Long>

    /** For custom exercises (Phase 5). */
    @Insert
    suspend fun insert(exercise: Exercise): Long

    @Query("SELECT seedKey FROM catalog_exercise WHERE seedKey IS NOT NULL")
    suspend fun seedKeys(): List<String>

    @Query("SELECT * FROM catalog_exercise ORDER BY name COLLATE NOCASE")
    fun observeAll(): Flow<List<Exercise>>

    @Query("SELECT * FROM catalog_exercise WHERE id = :id")
    suspend fun get(id: Long): Exercise?

    @Query("SELECT * FROM catalog_exercise WHERE id IN (:ids)")
    suspend fun getByIds(ids: List<Long>): List<Exercise>

    @Query("SELECT * FROM catalog_exercise WHERE name = :name COLLATE NOCASE LIMIT 1")
    suspend fun findByName(name: String): Exercise?

    @Query("SELECT COUNT(*) FROM catalog_exercise")
    suspend fun count(): Int
}
