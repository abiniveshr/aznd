package com.ashrdev.aznd.ui.workout

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.ashrdev.aznd.data.workout.WorkoutWithExercises
import com.ashrdev.aznd.ui.common.BarPage
import com.ashrdev.aznd.ui.common.ScreenScaffold
import com.ashrdev.aznd.ui.common.ThirdAction
import com.ashrdev.aznd.ui.common.rememberSubPageBar
import com.ashrdev.aznd.ui.components.Button
import com.ashrdev.aznd.ui.components.Card

private const val PAGE_EXERCISES = 0
private const val PAGE_VIEW = 1
private const val PAGE_STATS = 2

private val WorkoutPages = listOf(
    BarPage("Exercises", Icons.AutoMirrored.Filled.List),
    BarPage("Workouts", Icons.Default.FitnessCenter),
    BarPage("Stats", Icons.Default.BarChart)
)

/**
 * The Workouts module: three swipable pages, opening on the middle one.
 *   Exercises | Workouts | Stats
 *  - Workouts: every workout with a Start button; tap a workout to see what is in it.
 *  - Exercises (swipe left): placeholder for now. Workouts are edited from their own screen.
 *  - Stats (swipe right): pick a workout to open its stats.
 */
@Composable
fun WorkoutLogScreen(
    viewModel: WorkoutViewModel,
    onOpenWorkout: (Long) -> Unit,
    onAddWorkout: () -> Unit,
    onOpenSession: (Long) -> Unit,
    onOpenWorkoutStats: (Long) -> Unit,
    onBack: () -> Unit,
    onHome: () -> Unit,
    onOpenSettings: () -> Unit,
    // Opens the Custom exercises list (add / edit / delete). Menu item hidden when null.
    onManageCustomExercises: (() -> Unit)? = null
) {
    val workouts by viewModel.Workouts.collectAsState()
    val active by viewModel.activeSession.collectAsState()
    var blockedDialog by remember { mutableStateOf(false) }
    var menuExpanded by remember { mutableStateOf(false) }
    val pagerState = rememberPagerState(initialPage = PAGE_VIEW) { WorkoutPages.size }
    val subPages = rememberSubPageBar(pagerState, WorkoutPages)

    if (blockedDialog) {
        val running = active
        AlertDialog(
            onDismissRequest = { blockedDialog = false },
            title = { Text("Session already running") },
            text = {
                Text("You have an unfinished ${running?.workoutName.orEmpty()} session. Finish or discard it before starting another.")
            },
            confirmButton = {
                TextButton(onClick = {
                    blockedDialog = false
                    if (running != null) onOpenSession(running.workoutId)
                }) { Text("Go to session") }
            },
            dismissButton = {
                TextButton(onClick = { blockedDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Only one session can run at a time: starting another workout is blocked while one is open.
    val start: (WorkoutWithExercises) -> Unit = { item ->
        val running = active
        if (running != null && running.workoutId != item.Workout.id) blockedDialog = true
        else onOpenSession(item.Workout.id)
    }

    val page = pagerState.currentPage
    ScreenScaffold(
        title = when (page) {
            PAGE_EXERCISES -> "Exercises"
            PAGE_STATS -> "Workout stats"
            else -> "Workouts"
        },
        onBack = onBack,
        onHome = onHome,
        onOpenSettings = onOpenSettings,
        subPages = subPages,
        topBarActions = {
            Box {
                IconButton(onClick = { menuExpanded = true }) {
                    Icon(Icons.Default.MoreVert, contentDescription = "More options")
                }
                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false }
                ) {
                    if (onManageCustomExercises != null) {
                        DropdownMenuItem(
                            text = { Text("Custom exercises") },
                            onClick = {
                                menuExpanded = false
                                onManageCustomExercises()
                            }
                        )
                    }
                    DropdownMenuItem(text = { Text("Delete data") }, enabled = false, onClick = {})
                    DropdownMenuItem(text = { Text("Export data") }, enabled = false, onClick = {})
                }
            }
        }
    ) { padding ->
        val bottom = padding.calculateBottomPadding()
        HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize()) { index ->
            when (index) {
                PAGE_EXERCISES -> ExercisesPage(bottomPadding = bottom)
                PAGE_STATS -> StatsPickerPage(
                    workouts = workouts,
                    bottomPadding = bottom,
                    onOpen = onOpenWorkoutStats
                )
                else -> ViewPage(
                    workouts = workouts,
                    bottomPadding = bottom,
                    runningSession = active,
                    onAdd = onAddWorkout,
                    onOpenWorkout = onOpenWorkout,
                    onOpenSession = onOpenSession,
                    onStart = start
                )
            }
        }
    }
}

// ---- Workouts page: view mode ----

@Composable
private fun ViewPage(
    workouts: List<WorkoutWithExercises>,
    bottomPadding: Dp,
    runningSession: ActiveSessionInfo?,
    onAdd: () -> Unit,
    onOpenWorkout: (Long) -> Unit,
    onOpenSession: (Long) -> Unit,
    onStart: (WorkoutWithExercises) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = bottomPadding),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        runningSession?.let { running ->
            item(key = "running") {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(onClick = { onOpenSession(running.workoutId) })
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Session in progress", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "${running.workoutName} · started ${formatClock(running.startedAt)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
        item(key = "add") {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onAdd)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(Modifier.width(12.dp))
                    Text("Add workout", style = MaterialTheme.typography.titleMedium)
                }
            }
        }
        if (workouts.isEmpty()) {
            item(key = "empty") {
                Text("No workouts yet.", style = MaterialTheme.typography.bodyMedium)
            }
        } else {
            items(workouts, key = { it.Workout.id }) { item ->
                val isRunning = runningSession?.workoutId == item.Workout.id
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onOpenWorkout(item.Workout.id) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.Workout.name, style = MaterialTheme.typography.titleMedium)
                            Text(
                                "${item.exercises.size} exercises · ${item.exercises.sumOf { it.sets.size }} sets",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Button(
                            onClick = { onStart(item) },
                            enabled = item.exercises.isNotEmpty()
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(Modifier.width(4.dp))
                            Text(if (isRunning) "Resume" else "Start")
                        }
                    }
                }
            }
        }
    }
}

// ---- Exercises page: placeholder ----

@Composable
private fun ExercisesPage(bottomPadding: Dp) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(start = 24.dp, end = 24.dp, top = 24.dp, bottom = bottomPadding),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            Icons.Default.FitnessCenter,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(12.dp))
        Text("Exercises", style = MaterialTheme.typography.titleMedium)
        Text(
            "Coming soon.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// ---- Stats page: pick a workout ----

@Composable
private fun StatsPickerPage(
    workouts: List<WorkoutWithExercises>,
    bottomPadding: Dp,
    onOpen: (Long) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = bottomPadding),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (workouts.isEmpty()) {
            item(key = "empty") { Text("No workouts yet.", style = MaterialTheme.typography.bodyMedium) }
        }
        items(workouts, key = { it.Workout.id }) { item ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpen(item.Workout.id) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(item.Workout.name, style = MaterialTheme.typography.titleMedium)
                        Text(
                            "${item.exercises.size} exercises",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = null)
                }
            }
        }
    }
}
