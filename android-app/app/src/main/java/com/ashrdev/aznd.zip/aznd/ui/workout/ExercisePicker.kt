package com.ashrdev.aznd.ui.workout

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ashrdev.aznd.ui.components.OutlinedTextField
import com.ashrdev.aznd.data.workout.Exercise
import com.ashrdev.aznd.data.workout.searchExercises

/**
 * Searchable exercise dropdown (ExposedDropdownMenuBox). Tapping opens it with an empty search box;
 * typing filters by name OR muscle (max 30 results, see searchExercises). It never opens by itself,
 * so a freshly added superset row stays closed until the user taps it.
 * Closed, the field shows the selected exercise's name.
 *
 * Note: Modifier.menuAnchor() without arguments is deprecated in Material3 1.3+ but still compiles;
 * switch to menuAnchor(MenuAnchorType.PrimaryEditable) when you upgrade.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExercisePicker(
    selected: Exercise?,
    exercises: List<Exercise>,
    onPick: (Exercise) -> Unit,
    modifier: Modifier = Modifier,
    label: String = "Exercise"
) {
    var expanded by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val results = remember(exercises, query) { searchExercises(exercises, query) }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { wantOpen ->
            if (wantOpen) query = ""
            expanded = wantOpen
        },
        modifier = modifier
    ) {
        OutlinedTextField(
            value = if (expanded) query else selected?.name.orEmpty(),
            onValueChange = {
                query = it
                expanded = true
            },
            label = { Text(label) },
            singleLine = true,
            keyboardOptions = KeyboardOptions.Default,
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth()
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            if (results.isEmpty()) {
                DropdownMenuItem(text = { Text("No matching exercise") }, onClick = {}, enabled = false)
            }
            results.forEach { e ->
                DropdownMenuItem(
                    leadingIcon = { MuscleBadge(e.primaryMuscle, e.photoPath, size = 28.dp) },
                    text = {
                        Column {
                            Text(e.name)
                            Text(
                                text = e.primaryMuscle.name.lowercase().replace('_', ' '),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    onClick = {
                        expanded = false
                        onPick(e)
                    }
                )
            }
        }
    }
}
